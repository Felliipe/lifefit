import React, { useRef, useEffect, useState } from 'react';
import { Trophy, Target, Clock } from 'lucide-react';
import { motion, useScroll, useTransform, animate, useInView } from 'framer-motion';

// Componente Helper para contar números
const Counter = ({ from, to, duration, suffix = '' }: { from: number, to: number, duration: number, suffix?: string }) => {
  const nodeRef = useRef<HTMLSpanElement>(null);
  const inView = useInView(nodeRef, { once: true });

  useEffect(() => {
    if (!inView) return;
    const node = nodeRef.current;
    if (!node) return;

    const controls = animate(from, to, {
      duration: duration,
      onUpdate(value) {
        node.textContent = `${value.toFixed(0)}${suffix}`;
      }
    });

    return () => controls.stop();
  }, [from, to, duration, inView, suffix]);

  return <span ref={nodeRef}>{from}{suffix}</span>;
};

const About: React.FC = () => {
  const containerRef = useRef<HTMLElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  // Parallax movement for background image
  const y = useTransform(scrollYProgress, [0, 1], ["-20%", "10%"]);

  return (
    <section ref={containerRef} id="about" className="py-12 md:py-24 bg-[#0a0a0a] relative overflow-hidden">
      {/* Background Image with Parallax */}
      <motion.div 
        style={{ y }}
        className="absolute inset-[-20%] h-[140%] w-full z-0 pointer-events-none"
      >
         <img 
            src="https://images.unsplash.com/photo-1558611848-73f7eb4001a1?auto=format&fit=crop&q=80&w=1920"
            alt="Gym Background Texture"
            className="w-full h-full object-cover grayscale opacity-10"
         />
         <div className="absolute inset-0 bg-gradient-to-b from-iron-black via-transparent to-iron-black"></div>
      </motion.div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-20">
          
          {/* Visual Side - Otimizado para mobile */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex-1 flex justify-center order-2 md:order-1 w-full"
          >
             <div className="relative w-40 h-40 md:w-full md:h-auto md:max-w-md md:aspect-square">
                <div className="absolute inset-0 bg-iron-red/20 rounded-full blur-[40px] md:blur-[80px] animate-pulse"></div>
                <div className="relative border border-white/10 bg-iron-black/50 backdrop-blur-sm p-4 md:p-8 rounded-2xl flex items-center justify-center h-full">
                  <Trophy className="w-16 h-16 md:w-48 md:h-48 text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]" strokeWidth={0.5} />
                </div>
                
                {/* Floating Badges Animated */}
                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -top-2 -right-2 md:-top-6 md:-right-6 bg-iron-dark border border-iron-gray p-2 md:p-4 rounded-lg shadow-xl flex items-center gap-2 md:gap-3"
                >
                  <div className="bg-iron-red p-1 md:p-2 rounded-full"><Target size={12} className="text-white md:w-5 md:h-5"/></div>
                  <div>
                    <p className="text-[8px] md:text-xs text-gray-400 uppercase font-bold">Foco em</p>
                    <p className="text-[10px] md:text-sm font-bold text-white">Resultados</p>
                  </div>
                </motion.div>

                <motion.div 
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  className="absolute -bottom-2 -left-2 md:-bottom-6 md:-left-6 bg-iron-dark border border-iron-gray p-2 md:p-4 rounded-lg shadow-xl flex items-center gap-2 md:gap-3"
                >
                  <div className="bg-white p-1 md:p-2 rounded-full"><Clock size={12} className="text-iron-black md:w-5 md:h-5"/></div>
                  <div>
                    <p className="text-[8px] md:text-xs text-gray-400 uppercase font-bold">Aberto</p>
                    <p className="text-[10px] md:text-sm font-bold text-white">Todos os dias</p>
                  </div>
                </motion.div>
             </div>
          </motion.div>

          {/* Text Side */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex-1 text-center md:text-left order-1 md:order-2"
          >
            <h2 className="font-display text-3xl md:text-6xl mb-4 md:mb-6 uppercase tracking-wide leading-tight">
              O melhor ambiente <br/> para sua <span className="text-iron-red">evolução</span>
            </h2>
            <motion.div 
              initial={{ width: 0 }}
              whileInView={{ width: 96 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="h-1 bg-iron-red mb-6 md:mb-8 mx-auto md:mx-0 rounded-full"
            />
            
            <div className="space-y-4 md:space-y-6">
              <p className="text-gray-300 text-sm md:text-lg leading-relaxed font-light">
                Na <strong className="text-white">LifeFit</strong>, não alugamos apenas equipamentos. Nós construímos um ecossistema focado no seu progresso. Com uma área de 1.500m², equipamentos importados e climatização inteligente, você treina com conforto e intensidade.
              </p>
              <p className="text-gray-300 text-sm md:text-lg leading-relaxed font-light">
                Aqui o seu suor vale a pena. Venha fazer parte de uma comunidade que respira esporte e superação todos os dias.
              </p>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-2 md:gap-4 border-t border-white/10 pt-6 md:pt-8">
              <div className="p-2 hover:bg-white/5 rounded transition-colors">
                <p className="text-xl md:text-3xl font-display text-white">
                  <Counter from={0} to={1500} duration={2} suffix="m²" />
                </p>
                <p className="text-[10px] md:text-xs text-gray-500 uppercase font-bold">Espaço</p>
              </div>
              <div className="p-2 hover:bg-white/5 rounded transition-colors">
                <p className="text-xl md:text-3xl font-display text-white">24h</p>
                <p className="text-[10px] md:text-xs text-gray-500 uppercase font-bold">Segurança</p>
              </div>
              <div className="p-2 hover:bg-white/5 rounded transition-colors">
                <p className="text-xl md:text-3xl font-display text-white">
                  +<Counter from={0} to={20} duration={2} />
                </p>
                <p className="text-[10px] md:text-xs text-gray-500 uppercase font-bold">Modalidades</p>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default About;