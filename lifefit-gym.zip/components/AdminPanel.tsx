import React, { useState, useEffect } from 'react';
import { X, Upload, Save, Trash2, Image as ImageIcon, AlertCircle } from 'lucide-react';
import Button from './Button';

interface AdminPanelProps {
  onClose: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const [heroImages, setHeroImages] = useState<string[]>(['', '', '']);
  const [logo, setLogo] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Carregar dados salvos ao abrir
    const savedHero1 = localStorage.getItem('custom_hero_0');
    const savedHero2 = localStorage.getItem('custom_hero_1');
    const savedHero3 = localStorage.getItem('custom_hero_2');
    const savedLogo = localStorage.getItem('custom_logo');

    setHeroImages([
      savedHero1 || '',
      savedHero2 || '',
      savedHero3 || ''
    ]);
    if (savedLogo) setLogo(savedLogo);
  }, []);

  const validateAndSave = (file: File, callback: (base64: string) => void) => {
    setError(null);
    // Limite de 800KB para evitar estourar o LocalStorage (5MB total)
    const MAX_SIZE = 800 * 1024; 
    
    if (file.size > MAX_SIZE) {
      setError(`A imagem "${file.name}" é muito grande (${(file.size / 1024).toFixed(0)}KB). O máximo permitido é 800KB.`);
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      try {
        callback(base64String);
      } catch (e) {
        setError("Erro ao salvar imagem. O armazenamento local pode estar cheio.");
      }
    };
    reader.readAsDataURL(file);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = e.target.files?.[0];
    if (file) {
      validateAndSave(file, (base64) => {
        const newImages = [...heroImages];
        newImages[index] = base64;
        setHeroImages(newImages);
        try {
          localStorage.setItem(`custom_hero_${index}`, base64);
          window.dispatchEvent(new Event('storage'));
        } catch (e) {
          setError("Armazenamento cheio. Tente imagens menores ou remova algumas antigas.");
        }
      });
    }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      validateAndSave(file, (base64) => {
        setLogo(base64);
        try {
          localStorage.setItem('custom_logo', base64);
          window.dispatchEvent(new Event('storage'));
        } catch (e) {
           setError("Armazenamento cheio. Tente uma imagem menor.");
        }
      });
    }
  };

  const clearImage = (key: string, index?: number) => {
    setError(null);
    if (index !== undefined) {
      const newImages = [...heroImages];
      newImages[index] = '';
      setHeroImages(newImages);
      localStorage.removeItem(`custom_hero_${index}`);
    } else {
      setLogo('');
      localStorage.removeItem(key);
    }
    window.dispatchEvent(new Event('storage'));
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-iron-dark border border-iron-gray w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-iron-black p-6 border-b border-iron-gray flex justify-between items-center">
          <div>
            <h2 className="font-display text-2xl text-white uppercase">Painel do Administrador</h2>
            <p className="text-gray-400 text-sm">Gerencie as imagens do site</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-900/30 border-l-4 border-iron-red p-4 mx-6 mt-6 flex items-start gap-3">
            <AlertCircle className="text-iron-red shrink-0" size={20} />
            <p className="text-sm text-gray-200">{error}</p>
          </div>
        )}

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-8 custom-scrollbar">
          
          {/* Seção Logo */}
          <section>
            <h3 className="text-iron-red font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
              <ImageIcon size={18} /> Logo do Site
            </h3>
            <div className="bg-iron-black p-4 rounded border border-iron-gray flex items-center gap-4">
              <div className="w-20 h-20 bg-iron-gray/30 rounded flex items-center justify-center overflow-hidden border border-dashed border-gray-600">
                {logo ? (
                  <img src={logo} className="w-full h-full object-contain" alt="Logo Preview" />
                ) : (
                  <span className="text-xs text-gray-500 text-center">Sem Logo</span>
                )}
              </div>
              <div className="flex-1">
                <p className="text-white text-sm font-bold mb-2">Upload do Logo</p>
                <div className="flex gap-2">
                  <label className="cursor-pointer bg-iron-gray hover:bg-white hover:text-black text-white px-4 py-2 rounded text-sm font-bold transition-colors flex items-center gap-2">
                    <Upload size={16} /> Escolher Arquivo
                    <input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
                  </label>
                  {logo && (
                    <button 
                      onClick={() => clearImage('custom_logo')}
                      className="bg-red-900/30 hover:bg-red-900/50 text-red-400 px-3 py-2 rounded transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-2">Recomendado: Imagem vertical PNG transparente (Max 800KB)</p>
              </div>
            </div>
          </section>

          {/* Seção Hero */}
          <section>
            <h3 className="text-iron-red font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
              <ImageIcon size={18} /> Imagens da Capa (Hero)
            </h3>
            <p className="text-gray-500 text-xs mb-4">As imagens passarão automaticamente (Slideshow). Se não enviar, o site tentará buscar na pasta /foto.</p>
            
            <div className="space-y-4">
              {heroImages.map((img, idx) => (
                <div key={idx} className="bg-iron-black p-4 rounded border border-iron-gray flex items-center gap-4">
                  <div className="w-32 h-20 bg-iron-gray/30 rounded flex items-center justify-center overflow-hidden border border-dashed border-gray-600 relative group">
                    {img ? (
                      <img src={img} className="w-full h-full object-cover" alt={`Hero ${idx + 1}`} />
                    ) : (
                      <span className="text-xs text-gray-500">Slot {idx + 1} Vazio</span>
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-white text-sm font-bold mb-2">Imagem {idx + 1}</p>
                    <div className="flex gap-2">
                      <label className="cursor-pointer bg-iron-gray hover:bg-white hover:text-black text-white px-4 py-2 rounded text-sm font-bold transition-colors flex items-center gap-2">
                        <Upload size={16} /> Enviar Foto
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, idx)} />
                      </label>
                      {img && (
                        <button 
                          onClick={() => clearImage(`custom_hero_${idx}`, idx)}
                          className="bg-red-900/30 hover:bg-red-900/50 text-red-400 px-3 py-2 rounded transition-colors"
                        >
                          <Trash2 size={18} />
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-2">Max 800KB por foto.</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

        </div>

        {/* Footer */}
        <div className="bg-iron-black p-4 border-t border-iron-gray flex justify-end">
          <Button onClick={() => window.location.reload()}>
            Salvar e Atualizar Site
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;