import React from 'react';
import { MapPin, Phone, Instagram } from 'lucide-react';
import Button from './Button';
import { motion } from 'framer-motion';

const Contact: React.FC = () => {
  const handleWhatsApp = () => {
    const message = "Olá, vim pelo site da LifeFit e gostaria de tirar algumas dúvidas.";
    const phoneNumber = "5511999998888";
    const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  // Codificando para evitar erros de URL no iframe
  const addressQuery = encodeURIComponent("Rua Delfino Mendes, 215, Cidade Alta");

  return (
    <section id="contact" className="bg-iron-black relative border-t border-iron-gray overflow-hidden">
      
      {/* Top: Content + Map */}
      <div className="grid md:grid-cols-2 min-h-[auto] md:min-h-[500px]">
        
        {/* Left: Contact Info Animated */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="p-6 md:p-20 flex flex-col justify-center bg-iron-dark order-2 md:order-1"
        >
          <h2 className="font-display text-3xl md:text-5xl uppercase text-white mb-6 md:mb-8 text-center md:text-left">
            Entre em <span className="text-iron-red">Contato</span>
          </h2>
          
          <div className="space-y-5 md:space-y-8 mb-8 md:mb-10">
            <div className="flex items-start gap-4 group">
              <div className="bg-iron-gray p-3 rounded text-iron-red group-hover:bg-iron-red group-hover:text-white transition-colors shrink-0">
                <MapPin size={20} className="md:w-6 md:h-6" />
              </div>
              <div>
                <h4 className="font-bold uppercase text-white mb-1 text-sm md:text-base">Localização</h4>
                <p className="text-gray-400 text-xs md:text-sm">Rua Delfino Mendes - N° 215<br/>Cidade alta</p>
              </div>
            </div>

            <div className="flex items-start gap-4 group">
              <div className="bg-iron-gray p-3 rounded text-iron-red group-hover:bg-iron-red group-hover:text-white transition-colors shrink-0">
                <Phone size={20} className="md:w-6 md:h-6" />
              </div>
              <div>
                <h4 className="font-bold uppercase text-white mb-1 text-sm md:text-base">Telefone / WhatsApp</h4>
                <p className="text-gray-400 text-xs md:text-sm">(11) 99999-8888<br/>(11) 3333-4444</p>
              </div>
            </div>

            <a 
              href="https://instagram.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-start gap-4 group cursor-pointer"
            >
              <div className="bg-iron-gray p-3 rounded text-iron-red group-hover:bg-iron-red group-hover:text-white transition-colors shrink-0">
                <Instagram size={20} className="md:w-6 md:h-6" />
              </div>
              <div>
                <h4 className="font-bold uppercase text-white mb-1 text-sm md:text-base">Siga-nos</h4>
                <p className="text-gray-400 text-xs md:text-sm">@lifefitgym_oficial</p>
              </div>
            </a>
          </div>

          <Button fullWidth onClick={handleWhatsApp}>
            Fale Conosco no WhatsApp
          </Button>
        </motion.div>

        {/* Right: Map - Animated Slide from Right */}
        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative w-full h-64 md:h-auto md:min-h-[400px] bg-gray-900 order-1 md:order-2 border-b md:border-b-0 md:border-l border-iron-gray"
        >
          <iframe 
            src={`https://maps.google.com/maps?q=${addressQuery}&t=&z=15&ie=UTF8&iwloc=&output=embed`}
            width="100%" 
            height="100%" 
            style={{ border: 0, filter: "grayscale(100%) invert(92%) contrast(83%)" }} 
            allowFullScreen={true} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            className="absolute inset-0"
            title="Mapa da Academia"
          ></iframe>
        </motion.div>
      </div>

      {/* Footer */}
      <footer className="bg-iron-black py-6 md:py-8 text-center border-t border-zinc-900">
        <p className="text-gray-500 text-xs md:text-sm">
          © {new Date().getFullYear()} LifeFit Gym. Todos os direitos reservados. <br className="md:hidden"/> Designed for strength.
        </p>
      </footer>

    </section>
  );
};

export default Contact;