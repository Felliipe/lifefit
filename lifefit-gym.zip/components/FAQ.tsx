import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { FAQS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';

const FAQ: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <section className="py-16 md:py-24 bg-iron-dark">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="text-center mb-10 md:mb-12">
          <h2 className="font-display text-3xl md:text-5xl uppercase text-white">Perguntas Frequentes</h2>
        </div>

        <div className="space-y-3 md:space-y-4">
          {FAQS.map((faq, index) => (
            <div 
              key={index} 
              className={`border transition-colors duration-300 ${activeIndex === index ? 'border-iron-red bg-iron-black' : 'border-iron-gray bg-iron-black'}`}
            >
              <button
                onClick={() => toggleAccordion(index)}
                className="w-full flex items-center justify-between p-4 md:p-6 text-left focus:outline-none"
              >
                <span className={`font-bold text-base md:text-lg uppercase ${activeIndex === index ? 'text-white' : 'text-gray-300'}`}>
                  {faq.question}
                </span>
                {activeIndex === index ? (
                  <Minus className="text-iron-red w-5 h-5 md:w-6 md:h-6 flex-shrink-0" />
                ) : (
                  <Plus className="text-gray-500 w-5 h-5 md:w-6 md:h-6 flex-shrink-0" />
                )}
              </button>

              <AnimatePresence>
                {activeIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 md:px-6 md:pb-6 text-sm md:text-base text-gray-400 leading-relaxed">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;