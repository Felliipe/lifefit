import React, { useState, useEffect } from 'react';
import { Menu, X, Dumbbell } from 'lucide-react';
import { NAV_ITEMS } from '../constants';
import Button from './Button';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [logoError, setLogoError] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    }
  }, []);

  const scrollToSection = (id: string) => {
    setIsMenuOpen(false);
    const element = document.getElementById(id.replace('#', ''));
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/10 backdrop-blur-md py-2 shadow-lg border-b border-white/10' : 'bg-transparent py-4 md:py-6'
      }`}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        {/* Logo Container */}
        <div className="relative flex items-center group">
          <a href="#" onClick={(e) => { e.preventDefault(); scrollToSection('home'); }} className="flex items-center gap-2 h-16 md:h-24 w-auto max-w-[200px] justify-start overflow-visible">
            {!logoError ? (
              <img 
                src="logo.png" 
                alt="LF Gym Logo" 
                className="h-full w-auto object-contain object-left transition-all duration-300 drop-shadow-lg"
                onError={() => setLogoError(true)}
              />
            ) : (
              <div className="flex items-center gap-2">
                <Dumbbell className="w-8 h-8 text-iron-red transition-transform group-hover:rotate-45" />
                <span className="text-2xl md:text-3xl font-display tracking-widest text-white">
                  LIFEFIT<span className="text-iron-red">GYM</span>
                </span>
              </div>
            )}
          </a>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_ITEMS.map((item) => (
            <a 
              key={item.label} 
              href={item.href}
              onClick={(e) => { e.preventDefault(); scrollToSection(item.href); }}
              className="text-sm font-bold uppercase tracking-wide text-gray-300 hover:text-iron-red transition-colors"
            >
              {item.label}
            </a>
          ))}
          <Button 
            variant="primary" 
            className="px-6 py-2 text-sm"
            onClick={() => scrollToSection('plans')}
          >
            Quero Treinar
          </Button>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white p-2"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-iron-black/95 backdrop-blur-xl border-b border-iron-gray py-6 px-6 flex flex-col gap-4 shadow-2xl animate-in slide-in-from-top-5 duration-300 h-screen">
          {NAV_ITEMS.map((item) => (
            <a 
              key={item.label} 
              href={item.href}
              onClick={(e) => { e.preventDefault(); scrollToSection(item.href); }}
              className="text-xl font-bold uppercase tracking-wide text-white hover:text-iron-red py-4 border-b border-white/10 text-center"
            >
              {item.label}
            </a>
          ))}
          <div className="mt-4">
            <Button 
              variant="primary" 
              fullWidth 
              onClick={() => scrollToSection('plans')}
              className="py-4 text-lg"
            >
              Quero Treinar
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;