import React, { useState, useEffect } from 'react';
import Button from './Button';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap } from 'lucide-react';

const Hero: React.FC = () => {
  // Lista de imagens que o site vai tentar carregar da pasta local
  const localImages = [
    "foto/hero.jpg",
    "foto/hero-2.jpg",
    "foto/hero-3.jpg"
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  // Slideshow timer
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % localImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const scrollToPlans = () => {
    document.getElementById('plans')?.scrollIntoView({ behavior: 'smooth' });
  };

  // Fallback Silencioso: Se a imagem local não existir, troca por uma do Unsplash
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    const target = e.target as HTMLImageElement;
    const fallbacks = [
      "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1920&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=1920&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?q=80&w=1920&auto=format&fit=crop"
    ];
    // Usa o índice atual para pegar um fallback correspondente (evita loop de erro)
    const fallbackUrl = fallbacks[currentIndex % fallbacks.length];
    
    if (target.src !== fallbackUrl) {
       target.src = fallbackUrl;
    }
  };

  return (
    <section id="home" className="relative h-screen min-h-[600px] flex items-center overflow-hidden bg-iron-black group/hero">
      {/* Background Slideshow */}
      <div className="absolute inset-0 z-0 bg-iron-black">
        <AnimatePresence mode='popLayout'>
            <motion.img 
              key={currentIndex} 
              src={localImages[currentIndex]}
              onError={handleImageError}
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              alt="Academia Background" 
              fetchPriority={currentIndex === 0 ? "high" : "auto"}
              className="absolute inset-0 w-full h-full object-cover object-center md:object-[center_30%]"
            />
        </AnimatePresence>
        
        {/* ==== EFEITOS DE ILUMINAÇÃO ==== */}
        <div className="absolute inset-0 bg-black/40 z-10"></div>
        {/* Efeito de luz vermelha centralizado para combinar com o alinhamento central */}
        <div className="absolute top-[-10%] left-1/2 transform -translate-x-1/2 w-[120%] md:w-[80%] h-[80%] bg-iron-red/20 blur-[100px] md:blur-[180px] rounded-full mix-blend-screen pointer-events-none z-10 animate-pulse duration-[5s]"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/90 z-10"></div>
        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] z-10 mix-blend-overlay"></div>
      </div>

      {/* Main Content Container */}
      <div className="container mx-auto px-4 md:px-6 relative z-20 flex flex-col h-full justify-center items-center pt-16 md:pt-0">
        
        {/* Conteúdo Texto - Agora Centralizado */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="w-full max-w-5xl text-center flex flex-col items-center"
        >
          <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8 }}
             className="mb-6 md:mb-4"
          >
             <span className="inline-block py-1.5 px-4 border border-iron-red/50 bg-iron-red/10 backdrop-blur-sm text-white text-[10px] md:text-sm font-bold uppercase tracking-[0.15em] rounded shadow-[0_0_15px_rgba(229,9,20,0.3)]">
               A MELHOR ACADEMIA DA REGIÃO
             </span>
          </motion.div>

          <h1 className="font-display text-white uppercase leading-[0.9] tracking-wide drop-shadow-2xl w-full flex flex-col items-center">
            <span className="block text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-2 tracking-widest">
              CHEGOU A HORA DE
            </span>
            
            {/* Fonte ajustada para não quebrar em telas pequenas */}
            <span className="block text-[3.5rem] sm:text-[5rem] md:text-[9rem] font-bold text-iron-red drop-shadow-[0_0_25px_rgba(229,9,20,0.6)] scale-y-110 transform my-2 md:my-0 leading-none">
              TRANSFORMAR
            </span>
            
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <span className="block text-[2.5rem] sm:text-[4rem] md:text-[7rem] font-bold text-white leading-none">
                SEU CORPO!
              </span>
               <motion.div 
                  animate={{ scale: [1, 1.2, 1], opacity: [0.8, 1, 0.8] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                  className="hidden sm:block"
                >
                  <Zap className="w-8 h-8 md:w-16 md:h-16 text-iron-red fill-iron-red drop-shadow-[0_0_15px_rgba(229,9,20,1)]" />
               </motion.div>
            </div>
          </h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="mt-6 md:mt-8 mb-8 md:mb-12 w-full"
          >
            <p className="text-gray-300 text-sm md:text-xl mt-2 max-w-xl md:max-w-2xl mx-auto leading-relaxed font-medium shadow-black drop-shadow-md px-4 md:px-0">
              Bem-vindo à <strong className="text-white">LifeFitGym</strong>. Estrutura completa e ambiente motivador preparado para quem quer ir além do básico.
            </p>
          </motion.div>

          <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8, delay: 0.6 }}
             className="flex justify-center w-full md:w-auto px-4 md:px-0"
          >
            <Button 
              variant="primary" 
              className="w-full md:w-auto relative overflow-hidden group text-base md:text-xl px-10 py-5 bg-gradient-to-r from-iron-red to-red-700 hover:from-red-600 hover:to-iron-red shadow-[0_0_20px_rgba(229,9,20,0.4)] hover:shadow-[0_0_40px_rgba(229,9,20,0.6)] transform md:skew-x-[-10deg] border-0 transition-all duration-300 rounded-lg md:rounded"
              onClick={scrollToPlans}
            >
              <div className="absolute top-0 -inset-full h-full w-1/2 z-5 block transform -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-20 animate-shimmer" />
              
              <div className="flex items-center justify-center gap-3 transform md:skew-x-[10deg]">
                <span>FAZER MATRÍCULA</span>
                <Zap className="w-5 h-5 text-yellow-300 fill-yellow-300 animate-pulse" />
              </div>
            </Button>
          </motion.div>
        </motion.div>

      </div>
      
      <style>{`
        @keyframes shimmer {
          100% {
            left: 125%;
          }
        }
        .animate-shimmer {
          animation: shimmer 2.5s infinite;
        }
      `}</style>
    </section>
  );
};

export default Hero;