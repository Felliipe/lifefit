import React from 'react';
import { Check, X, Star } from 'lucide-react';
import { PLANS } from '../constants';
import Button from './Button';
import { motion, Variants } from 'framer-motion';

interface PricingProps {
  onSelectPlan: (planName: string) => void;
}

const Pricing: React.FC<PricingProps> = ({ onSelectPlan }) => {
  
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const cardVariants: Variants = {
    hidden: { opacity: 0, y: 50 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" }
    }
  };

  return (
    <section id="plans" className="py-12 md:py-24 bg-iron-dark relative overflow-hidden">
      {/* Background Decorative Glow Animated */}
      <motion.div 
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[500px] h-[300px] md:h-[500px] bg-iron-red/5 rounded-full blur-[80px] md:blur-[120px] pointer-events-none"
      />

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8 md:mb-16"
        >
          <h2 className="font-display text-3xl md:text-6xl mb-2 md:mb-3 uppercase text-white tracking-wide">Nossos <span className="text-iron-red">Planos</span></h2>
          <p className="text-gray-400 text-xs md:text-base font-medium max-w-xl mx-auto">
            Investimento simples, resultados reais. Sem taxas escondidas.
          </p>
        </motion.div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-6 md:gap-8 max-w-5xl mx-auto items-center"
        >
          {PLANS.map((plan) => (
            <motion.div 
              key={plan.name}
              variants={cardVariants}
              whileHover={{ y: -10, transition: { duration: 0.3 } }}
              className={`relative p-5 md:p-8 flex flex-col rounded-lg transition-all duration-500 group ${
                plan.recommended 
                  ? 'bg-iron-gray/80 border-2 border-iron-red shadow-[0_0_20px_rgba(229,9,20,0.15)] md:shadow-[0_0_30px_rgba(229,9,20,0.15)] md:scale-105 z-10' 
                  : 'bg-iron-black/60 border border-white/5 hover:border-iron-gray hover:bg-iron-black'
              }`}
            >
              {plan.recommended && (
                <div className="absolute -top-3 md:-top-4 left-1/2 transform -translate-x-1/2 bg-iron-red text-white text-[10px] md:text-xs font-bold uppercase py-1 px-3 md:px-4 tracking-widest rounded-full shadow-lg flex items-center gap-1">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  >
                    <Star size={10} fill="white" />
                  </motion.div>
                   Mais Popular
                </div>
              )}

              <h3 className="font-display text-xl md:text-4xl uppercase mb-2 tracking-wide">{plan.name}</h3>
              
              <div className="flex items-end gap-1 mb-4 md:mb-8 pb-4 md:pb-8 border-b border-white/10">
                <span className="text-base md:text-lg text-gray-400 font-medium mb-1">R$</span>
                <span className="text-4xl md:text-6xl font-bold text-white">{plan.price}</span>
                <span className="text-gray-500 text-sm md:text-base font-medium mb-1">{plan.period}</span>
              </div>

              <ul className="flex-1 space-y-3 md:space-y-4 mb-6 md:mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm md:text-base group-hover:pl-1 transition-all duration-300">
                    <div className={`p-0.5 mt-0.5 rounded-full ${feature.included ? 'bg-iron-red/20' : 'bg-gray-800'}`}>
                       {feature.included ? (
                        <Check className="w-3 h-3 md:w-4 md:h-4 text-iron-red shrink-0" />
                      ) : (
                        <X className="w-3 h-3 md:w-4 md:h-4 text-gray-600 shrink-0" />
                      )}
                    </div>
                    <span className={feature.included ? 'text-gray-200 font-medium' : 'text-gray-600 line-through'}>
                      {feature.text}
                    </span>
                  </li>
                ))}
              </ul>

              <Button 
                variant={plan.recommended ? 'primary' : 'outline'} 
                fullWidth
                onClick={() => onSelectPlan(plan.name)}
                className={plan.recommended ? "shadow-lg shadow-red-900/20 py-3 md:py-3" : "py-3 md:py-3"}
              >
                Assinar Agora
              </Button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;