import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, CheckCircle, User, Phone, Mail, Target } from 'lucide-react';
import Button from './Button';

interface RegistrationModalProps {
  planName: string;
  onClose: () => void;
}

const RegistrationModal: React.FC<RegistrationModalProps> = ({ planName, onClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    goal: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Formata a mensagem para o WhatsApp
    const message = `*NOVA MATRÍCULA - LIFEFIT*%0A%0A` +
      `Olá, gostaria de finalizar minha matrícula!%0A%0A` +
      `📋 *Plano Escolhido:* ${planName}%0A` +
      `👤 *Nome:* ${formData.name}%0A` +
      `📱 *Telefone:* ${formData.phone}%0A` +
      `📧 *Email:* ${formData.email}%0A` +
      `🎯 *Objetivo:* ${formData.goal || 'Não informado'}%0A%0A` +
      `Aguardo as instruções de pagamento.`;

    const phoneNumber = "5511999998888"; // Número da academia
    const url = `https://wa.me/${phoneNumber}?text=${message}`; // Não codificamos novamente a mensagem inteira pois os %0A já estão formatados, mas é mais seguro usar encodeURIComponent se for texto livre.
    
    // Usando encodeURIComponent corretamente para garantir caracteres especiais
    const safeMessage = encodeURIComponent(`*NOVA MATRÍCULA - LIFEFIT*\n\nOlá, gostaria de finalizar minha matrícula!\n\n📋 *Plano Escolhido:* ${planName}\n👤 *Nome:* ${formData.name}\n📱 *Telefone:* ${formData.phone}\n📧 *Email:* ${formData.email}\n🎯 *Objetivo:* ${formData.goal || 'Não informado'}\n\nAguardo as instruções de pagamento.`);
    
    window.open(`https://wa.me/${phoneNumber}?text=${safeMessage}`, '_blank');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/90 backdrop-blur-sm"
      />

      {/* Modal */}
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="relative w-full max-w-lg bg-iron-dark border border-iron-gray rounded-lg shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="bg-iron-black p-6 border-b border-iron-gray flex justify-between items-center">
          <div>
            <h3 className="font-display text-2xl text-white uppercase tracking-wide">Finalizar Matrícula</h3>
            <p className="text-iron-red text-sm font-bold uppercase mt-1">Plano Selecionado: {planName}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="space-y-4">
            
            {/* Nome */}
            <div className="relative">
              <label className="block text-xs font-bold uppercase text-gray-500 mb-1">Nome Completo</label>
              <div className="relative">
                <User className="absolute left-3 top-3 text-iron-red w-5 h-5" />
                <input 
                  required
                  type="text" 
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Seu nome aqui"
                  className="w-full bg-iron-black border border-iron-gray rounded p-3 pl-10 text-white focus:border-iron-red focus:outline-none transition-colors placeholder-gray-600"
                />
              </div>
            </div>

            {/* Telefone */}
            <div className="relative">
              <label className="block text-xs font-bold uppercase text-gray-500 mb-1">Telefone / WhatsApp</label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 text-iron-red w-5 h-5" />
                <input 
                  required
                  type="tel" 
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="(00) 00000-0000"
                  className="w-full bg-iron-black border border-iron-gray rounded p-3 pl-10 text-white focus:border-iron-red focus:outline-none transition-colors placeholder-gray-600"
                />
              </div>
            </div>

            {/* Email */}
            <div className="relative">
              <label className="block text-xs font-bold uppercase text-gray-500 mb-1">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 text-iron-red w-5 h-5" />
                <input 
                  type="email" 
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="seu@email.com"
                  className="w-full bg-iron-black border border-iron-gray rounded p-3 pl-10 text-white focus:border-iron-red focus:outline-none transition-colors placeholder-gray-600"
                />
              </div>
            </div>

            {/* Objetivo */}
            <div className="relative">
              <label className="block text-xs font-bold uppercase text-gray-500 mb-1">Principal Objetivo</label>
              <div className="relative">
                <Target className="absolute left-3 top-3 text-iron-red w-5 h-5" />
                <select 
                  name="goal"
                  value={formData.goal}
                  onChange={handleChange}
                  className="w-full bg-iron-black border border-iron-gray rounded p-3 pl-10 text-white focus:border-iron-red focus:outline-none transition-colors appearance-none"
                >
                  <option value="" disabled>Selecione uma opção</option>
                  <option value="Hipertrofia">Ganhar Massa Muscular</option>
                  <option value="Emagrecimento">Emagrecimento</option>
                  <option value="Condicionamento">Condicionamento Físico</option>
                  <option value="Saúde">Saúde e Bem-estar</option>
                </select>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <Button fullWidth type="submit" className="flex items-center justify-center gap-2">
              <CheckCircle size={20} />
              Enviar para WhatsApp
            </Button>
            <p className="text-center text-xs text-gray-500 mt-3">
              Ao enviar, você será redirecionado para nosso WhatsApp oficial para concluir o pagamento.
            </p>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default RegistrationModal;