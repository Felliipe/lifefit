import React from 'react';
import { TRAINERS } from '../constants';
import { Instagram, Twitter, Dumbbell } from 'lucide-react';
import { motion, Variants } from 'framer-motion';

const Trainers: React.FC = () => {
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const cardVariants: Variants = {
    hidden: { opacity: 0, y: 50 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" }
    }
  };

  return (
    <section id="trainers" className="py-12 md:py-32 bg-iron-black relative overflow-hidden">
      {/* Background Elements Animated */}
      <motion.div 
        animate={{ opacity: [0.2, 0.4, 0.2] }}
        transition={{ duration: 5, repeat: Infinity }}
        className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-iron-red/5 to-transparent pointer-events-none"
      />
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        
        {/* Título Impactante Centralizado */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="flex flex-col items-center text-center mb-8 md:mb-24 max-w-5xl mx-auto"
        >
          <h2 className="font-display text-3xl md:text-6xl lg:text-7xl uppercase text-white mb-4 md:mb-6 tracking-tight leading-[1.1] md:leading-[0.9]">
            TREINADORES <span className="text-iron-red block md:inline">ESPECIALIZADOS</span> PARA TE AJUDAR A <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400 block md:inline mt-2 md:mt-0">SUPERAR SEUS LIMITES!</span>
          </h2>
          <div className="flex items-center gap-4 mt-2">
            <div className="h-[2px] w-8 md:w-12 bg-iron-red"></div>
            <p className="text-gray-400 text-xs md:text-base font-medium uppercase tracking-widest">
              A elite do fitness pronta para você
            </p>
            <div className="h-[2px] w-8 md:w-12 bg-iron-red"></div>
          </div>
        </motion.div>

        {/* Grid de Cards */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-6 lg:gap-10"
        >
          {TRAINERS.map((trainer) => (
            <motion.div 
              key={trainer.id} 
              variants={cardVariants}
              className="group relative bg-iron-dark rounded-xl overflow-hidden transition-all duration-500 hover:-translate-y-2"
            >
              {/* Borda Neon no Hover */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-iron-red/80 rounded-xl transition-colors duration-300 z-20 pointer-events-none shadow-[0_0_0_0_rgba(229,9,20,0)] group-hover:shadow-[0_0_30px_rgba(229,9,20,0.2)]"></div>

              {/* Imagem - Altura otimizada para mobile (320px -> aspect-ratio) */}
              <div className="relative h-[300px] md:h-[400px] w-full overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-iron-black via-iron-black/20 to-transparent z-10"></div>
                <motion.img 
                  src={trainer.image} 
                  alt={trainer.name} 
                  className="w-full h-full object-cover object-top"
                  initial={{ filter: 'grayscale(100%)' }}
                  whileHover={{ scale: 1.1, filter: 'grayscale(0%)' }}
                  transition={{ duration: 0.5 }}
                />
                
                {/* Cargo (Floating Badge) */}
                <motion.div 
                  initial={{ x: 20, opacity: 0 }}
                  whileInView={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="absolute top-3 right-3 md:top-4 md:right-4 z-20"
                >
                  <div className="bg-iron-red/90 backdrop-blur text-white text-[10px] md:text-xs font-bold uppercase px-2 py-1 md:px-3 md:py-1.5 rounded skew-x-[-10deg] shadow-lg">
                    {trainer.role}
                  </div>
                </motion.div>
              </div>

              {/* Conteúdo */}
              <div className="relative z-20 -mt-16 md:-mt-20 p-5 md:p-6 pt-0">
                <h3 className="font-display text-2xl md:text-3xl text-white uppercase mb-2 md:mb-3 drop-shadow-lg group-hover:text-iron-red transition-colors">
                  {trainer.name}
                </h3>
                
                <p className="text-gray-400 text-xs md:text-sm leading-relaxed border-l-2 border-iron-red pl-3 md:pl-4 mb-4 md:mb-6 opacity-80 group-hover:opacity-100 transition-opacity">
                  {trainer.description}
                </p>

                {/* Social Icons */}
                <div className="flex gap-4 border-t border-white/5 pt-4">
                  <a href="#" className="bg-white/5 p-2 rounded hover:bg-iron-red hover:text-white text-gray-400 transition-all">
                    <Instagram size={16} className="md:w-[18px] md:h-[18px]" />
                  </a>
                  <a href="#" className="bg-white/5 p-2 rounded hover:bg-iron-red hover:text-white text-gray-400 transition-all">
                    <Twitter size={16} className="md:w-[18px] md:h-[18px]" />
                  </a>
                  <div className="ml-auto">
                    <Dumbbell className="text-iron-red/50 group-hover:text-iron-red transition-colors w-5 h-5 md:w-6 md:h-6" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Trainers;